package timeserveruserinterface;

/**
 *
 * @author kferens
 */
public interface TimeServerUserInterface {
    public abstract void update(String theMessage);    
}