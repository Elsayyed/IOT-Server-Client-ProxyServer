package frameworkuserinterface;

/**
 *
 * @author ferens
 */
public interface FrameworkUserInterface {
    public abstract void update(String theMessage);    
}
